package com.example.notekeepererrors

const val NOTE_POSITION = "EXTRA_NOTE_POSITION"
const val POSITION_NOTE_SET = -1
